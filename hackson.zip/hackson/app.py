from flask import Flask, render_template, jsonify, send_from_directory
import os

app = Flask(__name__)

IMAGE_FOLDER = "images"
app.config["IMAGE_FOLDER"] = IMAGE_FOLDER


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/process', methods=['POST'])
def process():
    """
    imagesフォルダ内の画像を取得してテキストを対応付け
    """
    image_text_map = {
        "image1.jpg": "りんご",
        "image2.jpg": "バナナ",
        "image3.jpg": "オレンジ"
    }

    files = [f for f in os.listdir(IMAGE_FOLDER) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]

    if not files:
        return jsonify({"error": "画像が見つかりません。"})

    table_rows = ""
    for f in files:
        img_url = f"/image/{f}"
        text = image_text_map.get(f, "不明な果物")
        row = f"""
            <tr>
                <td><img src="{img_url}" width="120"></td>
                <td>{text}</td>
            </tr>
        """
        table_rows += row

    html_table = f"""
        <table border="1" style="border-collapse:collapse; text-align:center;">
            <tr><th>画像</th><th>名前</th></tr>
            {table_rows}
        </table>
    """

    return jsonify({"table": html_table})


@app.route('/image/<filename>')
def serve_image(filename):
    """imagesフォルダ内の画像を配信"""
    return send_from_directory(app.config["IMAGE_FOLDER"], filename)


if __name__ == '__main__':
    app.run(debug=True)