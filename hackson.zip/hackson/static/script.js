document.getElementById("runButton").addEventListener("click", () => {
  fetch("/process", { method: "POST" })
    .then(response => response.json())
    .then(data => {
      if (data.error) {
        document.getElementById("result").innerText = data.error;
      } else {
        document.getElementById("result").innerHTML = data.table;
      }
    })
    .catch(error => {
      console.error("エラー:", error);
      document.getElementById("result").innerText = "エラーが発生しました。";
    });
});